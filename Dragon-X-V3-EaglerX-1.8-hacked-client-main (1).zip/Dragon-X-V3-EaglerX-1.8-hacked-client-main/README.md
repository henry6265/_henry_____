# Dragon-X-V3-EaglerX-1.8-hacked-client
the third version of the dragon-x eaglercraft client only works on 1.8 servers 


I take no responsaility for whateer punishment/s you may sustain from using this hacked client online.

Right SHIFT key opens the GUI and right clicking an option opens the folders and opens more options if you right click a hack you can set a hotkey to turn it off and onn and other things depending on witch one you right click.
